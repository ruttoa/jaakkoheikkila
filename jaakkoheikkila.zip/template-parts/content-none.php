<?php
/**
 * The template part for displaying a message that posts cannot be found
 */
?>
<div class="entry-content">
	<h2 class="nocontent-title"><?php _e( 'Sorry, nothing to display.', 'jaakkoheikkila' ); ?></h2>
</div>
