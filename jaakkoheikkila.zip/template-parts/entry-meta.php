<div class="entry-meta">
	<time class="date" datetime="<?php echo get_the_time('c'); ?>"><?php echo get_the_date(); ?></time>
</div>